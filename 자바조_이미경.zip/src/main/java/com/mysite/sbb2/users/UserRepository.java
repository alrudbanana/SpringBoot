package com.mysite.sbb2.users;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;



public interface UserRepository extends JpaRepository<Users, Integer> {
	
	//이름을 기준으로 찾기 
	Users findByname(String name);
	
	//아이디 번호 값 찾기
	Users findByidx(int idx);
	
	//값 수정 (save)
	
	
	//데이터 값을 정렬 (DESC)
	List<Users> findBynameLikeOrderByCreateDateAsc(String idx);
	List<Users> findBynameLikeOrderByCreateDateDesc(String idx);
	
	//모든 레코드를 정렬해서 출력 
	List <Users> findAllByOrderByCreateDateAsc();
	List <Users> findAllByOrderByCreateDateDesc(); //날짜기준으로 내림차순 
}
